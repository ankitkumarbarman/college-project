#include<iostream>
using namespace std;


int main(){

	char a[100];

	//cin>>a;
	//cin.getline(a,100); 
	//cin.getline(a,100,'.');
	//cout<<a;

	char b[] = {'1','a','b','c','\0'};
	cout<<b<<endl;


	return 0;
}